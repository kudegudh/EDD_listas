package com.mycompany.listas_ligadas;

public class IteratorList<TYPE> {
    private Node<TYPE> node;
    
    public IteratorList(Node<TYPE> node) {
        this.node = node;
    }
    
    public Node<TYPE> getNode() {
        return node;
    }

    public void setNode(Node<TYPE> node) {
        this.node = node;
    }
    
    public boolean haveNext() {
        if(this.node.getNext() == null) {
            return false;
        } else {
            return true;
        }
    }
    
    public Node<TYPE> getNext() {
        this.node = this.node.getNext();
        return this.node;
    }
}
