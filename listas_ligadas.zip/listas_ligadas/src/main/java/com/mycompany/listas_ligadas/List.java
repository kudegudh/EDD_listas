package com.mycompany.listas_ligadas;

public class List<TYPE> {
    private Node<TYPE> head;
    private Node<TYPE> tail;
    private int listLength;
    
    public List() {
        this.head = null;
        this.tail = null;
        this.listLength = 0;
    }

    public Node<TYPE> getHead() {
        return head;
    }

    public void setHead(Node<TYPE> head) {
        this.head = head;
    }

    public Node<TYPE> getTail() {
        return tail;
    }

    public void setTail(Node<TYPE> tail) {
        this.tail = tail;
    }

    public int getListLength() {
        return listLength;
    }

    public void setListLength(int listLength) {
        this.listLength = listLength;
    }
    
    public Node<TYPE> getNode(int position) {
        Node<TYPE> node = this.head;
        
        for(int i = 0; i < position - 1; i++) {
            node = node.getNext();
        }
        return node;
    }
    
    public void add(TYPE data) {
        Node<TYPE> node = new Node<TYPE>(data);
        
        if(this.head == null && this.tail == null) {
            this.head = node;
            this.tail = node;
            this.listLength++;
        } else {
            node.setNext(this.head);
            this.head.setPrev(node);
            this.head = node;
            this.listLength++;
        }
    }
    
    public void remove(TYPE data) {
        if(this.head != null && this.tail != null) {
            Node<TYPE> node = this.head;
            int list = this.listLength;
            
            for(int i = 0; i < this.listLength; i++) {
                if(node.getData().equals(data)) {
                    if(node.getPrev() == null) {
                        this.head = node.getNext();
                        node.getNext().setPrev(null);
                    } else if(node.getNext() == null) {
                        this.tail = node.getPrev();
                        node.getPrev().setNext(null);
                    } else {
                        node.getPrev().setNext(node.getNext());
                        node.getNext().setPrev(node.getPrev());
                    }
                    node = node.getNext();
                    list--;
                } else {
                    node = node.getNext();
                }
            }
            this.listLength = list;
        }
    }
    
    public IteratorList<TYPE> iterator() {
        return new IteratorList<TYPE>(this.head);
    }
}
