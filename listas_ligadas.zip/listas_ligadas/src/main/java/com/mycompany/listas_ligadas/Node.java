package com.mycompany.listas_ligadas;

public class Node<TYPE> {
    private TYPE data;
    private Node<TYPE> next;
    private Node<TYPE> prev;
    
    public Node(TYPE data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
    
    public TYPE getData() {
        return data;
    }

    public void setData(TYPE data) {
        this.data = data;
    }

    public Node<TYPE> getNext() {
        return next;
    }

    public void setNext(Node<TYPE> next) {
        this.next = next;
    }

    public Node<TYPE> getPrev() {
        return prev;
    }

    public void setPrev(Node<TYPE> prev) {
        this.prev = prev;
    }
}
