package com.mycompany.listas_ligadas;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        List<Integer> list = new List();
        
        List<Integer> list2 = new List();
        ArrayList<Integer> arr = new ArrayList<Integer>();
        
        
        list.add(2);
        list.add(5);
        list.add(3);
        list.add(4);
        
        System.out.println("Tamanho da lista: "+list.getListLength());
        System.out.println("Head da lista: "+list.getHead().getData());
        System.out.println("Tail da lista: "+list.getTail().getData());
        
        list.remove(4);
        System.out.println("\nTamanho da lista: "+list.getListLength());
        System.out.println("Head da lista: "+list.getHead().getData());
        
        list.remove(2);
        System.out.println("\nTamanho da lista: "+list.getListLength());
        System.out.println("Tail da lista: "+list.getTail().getData());
        
        
        
        int qnt = 100000;
        long tmpInit;
        long tmpEnd;
        
        //create
        tmpInit = System.currentTimeMillis();
        for(int i = 0; i < qnt; i++) {
            arr.add(i);
        }
        tmpEnd = System.currentTimeMillis();
        System.out.println("\n\n"+(tmpEnd-tmpInit)+"ms para adicionar "+qnt+" itens no array");
        
        tmpInit = System.currentTimeMillis();
        for(int i = 0; i < qnt; i++) {
            list2.add(i);
        }
        tmpEnd = System.currentTimeMillis();
        System.out.println("\n\n"+(tmpEnd-tmpInit)+"ms para adicionar "+qnt+" itens na lista sem iterador");
        
        //read
        tmpInit = System.currentTimeMillis();
        for(int i = 0; i < qnt; i++) {
            arr.get(i);
        }
        tmpEnd = System.currentTimeMillis();
        System.out.println("\n\n"+(tmpEnd-tmpInit)+"ms para ler "+qnt+" itens no array");
        
        tmpInit = System.currentTimeMillis();
        for(int i = 0; i < qnt; i++) {
            list2.getNode(i);
        }
        tmpEnd = System.currentTimeMillis();
        System.out.println("\n\n"+(tmpEnd-tmpInit)+"ms para ler "+qnt+" itens na lista sem iterador");
        
        
        IteratorList<Integer> iterator = list2.iterator();
        tmpInit = System.currentTimeMillis();
        while(iterator.haveNext()) {
            iterator.getNext();
        }
        tmpEnd = System.currentTimeMillis();
        System.out.println("\n\n"+(tmpEnd-tmpInit)+"ms para ler "+qnt+" itens na lista com iterador");
        
    }
}
